# Calculator

iPhone-style calculator for Android. Black theme, round buttons, orange operators, AC/C, +/-, %, chained operations, repeat-equals, thousands separators, swipe the display to delete a digit.
