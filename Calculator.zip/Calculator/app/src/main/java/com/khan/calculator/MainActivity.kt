package com.khan.calculator

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext
import java.util.Locale

class MainActivity : Activity() {

    private class Key(
        val sym: String,
        val base: Int,
        val press: Int,
        val text: Int,
        val isOp: Boolean
    )

    // ---- calculator state (mirrors the iPhone calculator) ----
    private var cur = "0"          // number shown on screen (raw, no commas)
    private var fresh = false      // next digit starts a new number
    private var acc = 0.0          // left operand
    private var op: String? = null // pending operator
    private var opJust = false     // last key pressed was an operator
    private var lastOp: String? = null
    private var lastVal = 0.0
    private var error = false
    private var showC = false      // AC button shows "C" while typing

    private lateinit var display: TextView
    private lateinit var acBtn: TextView
    private val opButtons = ArrayList<TextView>()

    private val ORANGE = 0xFFFF9F0A.toInt()
    private var downX = 0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        update()
    }

    // ---------------- UI ----------------

    private fun buildUi(): View {
        val screenW = resources.displayMetrics.widthPixels
        val gap = dp(14)
        val size = (screenW - gap * 5) / 4

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(0, 0, 0, dp(12))
        }

        display = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.BOTTOM or Gravity.END
            maxLines = 1
            includeFontPadding = false
            setPadding(dp(28), 0, dp(28), dp(8))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) {
                    downX = e.x
                } else if (e.action == MotionEvent.ACTION_UP) {
                    if (Math.abs(e.x - downX) > dp(50)) backspace()
                }
                true
            }
        }
        root.addView(
            display,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        val rows = arrayOf(
            arrayOf("AC", "+/−", "%", "÷"),
            arrayOf("7", "8", "9", "×"),
            arrayOf("4", "5", "6", "−"),
            arrayOf("1", "2", "3", "+"),
            arrayOf("0", ".", "=")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(gap / 2, 0, gap / 2, 0)
            }
            for (s in r) {
                val bw = if (s == "0") size * 2 + gap else size
                val btn = makeButton(s, keyFor(s), bh = size)
                val lp = LinearLayout.LayoutParams(bw, size)
                lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
                row.addView(btn, lp)
            }
            root.addView(
                row,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        return root
    }

    private fun keyFor(s: String): Key = when (s) {
        "AC", "+/−", "%" ->
            Key(s, 0xFFA5A5A5.toInt(), 0xFFD9D9D9.toInt(), Color.BLACK, false)
        "÷", "×", "−", "+", "=" ->
            Key(s, ORANGE, 0xFFFCC78E.toInt(), Color.WHITE, s != "=")
        else ->
            Key(s, 0xFF333333.toInt(), 0xFF737373.toInt(), Color.WHITE, false)
    }

    private fun setBg(v: View, color: Int) {
        (v.background as GradientDrawable).setColor(color)
    }

    private fun restColor(k: Key): Int =
        if (k.isOp && opJust && op == k.sym) Color.WHITE else k.base

    private fun makeButton(label: String, k: Key, bh: Int): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.tag = k
        tv.setTextColor(k.text)
        val sp = when (label) {
            "AC" -> 30f
            "+/−" -> 28f
            "%" -> 32f
            "÷", "×", "−", "+", "=" -> 42f
            else -> 38f
        }
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        tv.includeFontPadding = false
        if (label == "0") {
            tv.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            tv.setPadding(bh * 3 / 8, 0, 0, 0)
        } else {
            tv.gravity = Gravity.CENTER
        }
        val bg = GradientDrawable()
        bg.cornerRadius = bh / 2f
        bg.setColor(k.base)
        tv.background = bg
        tv.isClickable = true
        tv.setOnTouchListener { v, e ->
            val key = v.tag as Key
            if (e.action == MotionEvent.ACTION_DOWN) {
                setBg(v, key.press)
            } else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                setBg(v, restColor(key))
            }
            false
        }
        tv.setOnClickListener {
            onKey(label)
            update()
        }
        if (k.isOp) opButtons.add(tv)
        if (label == "AC") acBtn = tv
        return tv
    }

    private fun update() {
        val t = addCommas(cur)
        display.text = t
        val len = t.length
        val sp = when {
            len <= 6 -> 88f
            len == 7 -> 78f
            len == 8 -> 70f
            len == 9 -> 62f
            len <= 11 -> 50f
            else -> 42f
        }
        display.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        acBtn.text = if (showC) "C" else "AC"
        for (tv in opButtons) {
            val k = tv.tag as Key
            val selected = opJust && op == k.sym
            setBg(tv, if (selected) Color.WHITE else k.base)
            tv.setTextColor(if (selected) ORANGE else Color.WHITE)
        }
    }

    // ---------------- logic ----------------

    private fun onKey(s: String) {
        if (error && s != "AC") resetAll()
        when (s) {
            "AC" -> {
                if (showC) {
                    cur = "0"
                    fresh = false
                    showC = false
                } else {
                    resetAll()
                }
            }
            "+/−" -> negate()
            "%" -> percent()
            "÷", "×", "−", "+" -> operator(s)
            "=" -> equals()
            "." -> decimal()
            else -> digit(s)
        }
    }

    private fun resetAll() {
        cur = "0"
        fresh = false
        acc = 0.0
        op = null
        opJust = false
        lastOp = null
        lastVal = 0.0
        error = false
        showC = false
    }

    private fun value(): Double = cur.toDoubleOrNull() ?: 0.0

    private fun digitCount(): Int = cur.count { it in '0'..'9' }

    private fun digit(d: String) {
        if (fresh) {
            cur = "0"
            fresh = false
        }
        opJust = false
        if (cur == "0") {
            cur = d
        } else if (cur == "-0") {
            cur = "-$d"
        } else if (digitCount() < 9) {
            cur += d
        }
        showC = true
    }

    private fun decimal() {
        if (fresh) {
            cur = "0"
            fresh = false
        }
        opJust = false
        if (!cur.contains('.') && digitCount() < 9) cur += "."
        showC = true
    }

    private fun negate() {
        if (fresh) {
            if (op != null && opJust) {
                cur = "-0"
                fresh = false
                opJust = false
                showC = true
            } else {
                cur = fmt(-value())
            }
        } else {
            cur = if (cur.startsWith("-")) cur.substring(1) else "-$cur"
        }
    }

    private fun percent() {
        val v = value()
        val r = if (op == "+" || op == "−") acc * v / 100.0 else v / 100.0
        cur = fmt(r)
        fresh = true
        opJust = false
    }

    private fun operator(s: String) {
        val v = value()
        val o = op
        if (o != null && !opJust) {
            val r = apply(acc, v, o)
            cur = fmt(r)
            if (error) return
            acc = r
        } else if (o == null) {
            acc = v
        }
        op = s
        opJust = true
        fresh = true
        lastOp = null
    }

    private fun equals() {
        val o = op
        if (o != null) {
            val v = value()
            val r = apply(acc, v, o)
            lastOp = o
            lastVal = v
            op = null
            cur = fmt(r)
            acc = r
        } else {
            val lo = lastOp
            if (lo != null) {
                val r = apply(value(), lastVal, lo)
                cur = fmt(r)
                acc = r
            }
        }
        fresh = true
        opJust = false
        showC = false
    }

    private fun backspace() {
        if (fresh || error) return
        cur = if (cur.length <= 1 || (cur.length == 2 && cur.startsWith("-"))) {
            "0"
        } else {
            cur.dropLast(1)
        }
        update()
    }

    private fun apply(a: Double, b: Double, o: String): Double = when (o) {
        "+" -> a + b
        "−" -> a - b
        "×" -> a * b
        else -> if (b == 0.0) Double.NaN else a / b
    }

    /** Turn a result into the raw string shown on screen (max ~9 digits). */
    private fun fmt(r: Double): String {
        if (r.isNaN() || r.isInfinite()) {
            error = true
            return "Error"
        }
        val a = Math.abs(r)
        if (a != 0.0 && (a >= 1e9 || a < 1e-6)) {
            val s = String.format(Locale.US, "%.6e", r)
            val parts = s.split("e")
            var m = parts[0]
            if (m.contains('.')) m = m.trimEnd('0').trimEnd('.')
            val e = parts[1].toInt()
            return m + "e" + (if (e >= 0) "+$e" else "$e")
        }
        val bd = BigDecimal(r).round(MathContext(9)).stripTrailingZeros()
        return bd.toPlainString()
    }

    private fun addCommas(raw: String): String {
        if (raw == "Error" || raw.contains('e')) return raw
        val neg = raw.startsWith("-")
        val body = if (neg) raw.substring(1) else raw
        val dot = body.indexOf('.')
        val ip = if (dot >= 0) body.substring(0, dot) else body
        val fp = if (dot >= 0) body.substring(dot) else ""
        val sb = StringBuilder()
        for ((i, ch) in ip.withIndex()) {
            if (i > 0 && (ip.length - i) % 3 == 0) sb.append(',')
            sb.append(ch)
        }
        return (if (neg) "-" else "") + sb.toString() + fp
    }
}
